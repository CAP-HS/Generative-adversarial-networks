# Generative-adversarial-networks

Adversarial attack and defense for indoor object detection

Deep neural network is vulnerable to an adversarial attack. nowadays it is hard to think about the entertainment industry and trade whit out the implementation of deep neural network technology. For instance, Netflix, YouTube, Spotify can be a good example to show how often an individual comes into contact whit a neural network. As a result, to make the neural network perform well and produce a good prediction to new data we need to establish a model accuracy and resilience to adversarial manipulation. In this work, we are implementing an adversarial neural network for indoor object detection and try to show possible unavoidable problems that can arise either from model complexity or accuracy of training
